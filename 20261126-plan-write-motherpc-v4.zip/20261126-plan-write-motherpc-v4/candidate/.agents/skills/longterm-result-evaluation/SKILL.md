---
name: longterm-result-evaluation
description: "롱텀업무 6 LT 전용 근거·초안·20L 입력/저장 개발; 기관 RFID 상세 호환 점검 중"
---

# longterm-result-evaluation

모든 롱텀 스킬의 서술형 업무 문장은 확인된 사실을 구체적으로 자연스러운 업무 기록체로 쓴다. 특정 날짜와 출처 설명은 본문에서 제외하고, 내부 근거의 출처·기록일과 필수 날짜 입력란은 보존한다. 직접 관찰을 꾸미거나 사실을 추정하지 않는다. 명시적으로 날짜·출처가 필요한 경우는 해당 지시와 서식을 따른다.

이 작업 폴더의 `node control.cjs menu`로 현재 등록을 확인한다. `node control.cjs skill longterm-result-evaluation`가 알려 주는 현재 버전 지침을 읽고 실행한다. 설정·자료·완료/unknown 이력을 보존한다. 실제 사이트 쓰기는 그 업무의 사용자 지시/승인 범위만 수행한다. 브라우저는 Aside CLI를 사용하고 MCP를 설치하지 않는다.

롱텀 업무에서는 [공통 문제 해결 질문 스킬](../sequential-clarification/SKILL.md)을 항상 함께 읽고 적용한다. 궁금한 점·불명확한 내용·문제·오류·막힌 작업은 사용자에게 먼저 질문한다. 현재 질문 전체를 먼저 안내하고 한 번에 하나씩 답을 받아 해결하며 이미 받은 답은 재질문하지 않는다.
