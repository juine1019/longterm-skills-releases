'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const bridge=require('./desk-bridge.cjs'),{createDeskClient}=require('./desk-client.cjs'),{publishDraft}=require('./desk-publish.cjs');
function draft(text){const data={subjectKey:'a'.repeat(64),planKey:'b'.repeat(64),servicePeriod:{from:'2026-01-01',to:'2026-12-31'},operation:'create',evaluationId:null,revision:1,evaluationDate:null,evaluationKind:'02',goals:[],observations:[],summary:{text},overallComment:{text:'가상'},bundleHash:'c'.repeat(64),evidence:[],localWorkKey:'d'.repeat(64)};data.evaluationKey=bridge.evaluationKey(data);return{data,contentHash:bridge.deskContentHash(data)};}
test('6-1 reads all revisions, skips identical content, and assigns a new revision to changed content',async()=>{
 const old=draft('기존'),record={...old.data,orgId:'DESK',status:'draft',version:1,contentHash:old.contentHash};let writes=0;const records=new Map([[record.evaluationKey,record]]);
 const request=async(method,path,body)=>{if(path==='/api/org')return{id:'DESK',me:{role:'admin'}};if(path.endsWith('?includeRevisions=1'))return{orgId:'DESK',viewerKey:'e'.repeat(64),includeRevisions:true,items:[...records.values()].map(x=>({evaluationKey:x.evaluationKey,version:x.version}))};if(method==='GET'&&path.startsWith('/api/evaluation-results/'))return records.get(path.split('/').at(-1));if(method==='PUT'){writes++;const item={...body.data,status:'draft',version:1,contentHash:bridge.deskContentHash(body.data)};records.set(item.evaluationKey,item);return item;}throw Error('UNEXPECTED');};
 const client=createDeskClient({request,expectedOrg:'DESK'});
 assert.equal((await publishDraft({built:old,client,deskOrgId:'DESK',requestId:'request-0001'})).status,'existing');assert.equal(writes,0);
 const result=await publishDraft({built:draft('변경'),client,deskOrgId:'DESK',requestId:'request-0002'});assert.equal(result.status,'verified');assert.equal(result.revision,2);assert.equal(writes,1);assert.equal(records.get(record.evaluationKey).summary.text,'기존');
});
