# 공통 업무 지침

이 폴더에서 작업하기 전에 `AGENTS.md`를 읽고 따른다. 롱텀 업무에서는 `.agents/skills/sequential-clarification/SKILL.md`를 항상 함께 읽고 적용한다. 필요한 질문 전체를 먼저 안내한 뒤 한 번에 한 질문씩 답을 받아 문제를 해결하고 이미 받은 답은 재질문하지 않는다.

## Codex·Claude Code 동시 인계

작업 종료·정리·인계 요청에는 항상 Codex용과 Claude Code용 문서를 함께 작성·갱신한다. 상세 작성 기준과 실행 경계는 `AGENTS.md`의 동시 인계 항목을 따른다. 한쪽 문서를 갱신하면 다른 쪽의 완료 사실·검증·남은 작업도 맞춘다. Claude Code에 없는 Codex 전용 도구를 전제로 작업하지 않는다.

2026-11-26 작업을 이어받을 때는 `state/handoffs/HANDOFF-CLAUDE-CODE-2026-11-26.txt`를 먼저 읽는다. 노트북의 실제 기관 자료가 필요한 경우에만 로컬 전용 `다음작업_ClaudeCode_2026-11-26.txt`를 읽고 공개 저장소에 올리지 않는다. 다음 종료 시에는 이 시작 위치를 최신 Claude Code 인계문서로 갱신한다.
